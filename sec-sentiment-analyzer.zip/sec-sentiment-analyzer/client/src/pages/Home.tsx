import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import FileUpload from '@/components/FileUpload';
import SentimentResults from '@/components/SentimentResults';
import { FileText, BarChart3 } from 'lucide-react';
import { toast } from 'sonner';

export default function Home() {
  const [fileContent, setFileContent] = useState('');
  const [fileName, setFileName] = useState('');
  const [results, setResults] = useState<any>(null);

  const analyzeDocument = trpc.analyzeDocument.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        setResults(data);
        toast.success('Análisis completado');
      }
    },
    onError: (error) => {
      toast.error('Error en el análisis: ' + error.message);
    },
  });

  const handleFileLoaded = async (content: string, name: string) => {
    setFileContent(content);
    setFileName(name);
    setResults(null);

    // Iniciar análisis automáticamente
    analyzeDocument.mutate({
      content,
      fileName: name,
    });
  };

  const handleNewAnalysis = () => {
    setFileContent('');
    setFileName('');
    setResults(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-border sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-3 mb-2">
            <BarChart3 className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold text-foreground">SEC Sentiment Analyzer</h1>
          </div>
          <p className="text-muted-foreground">
            Análisis de sentimiento de documentos SEC usando IA local
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {!results ? (
          <div className="space-y-8">
            {/* Upload Section */}
            <div className="bg-white rounded-lg shadow-sm p-8">
              <div className="flex items-center gap-2 mb-6">
                <FileText className="w-6 h-6 text-primary" />
                <h2 className="text-2xl font-bold text-foreground">Cargar Documento</h2>
              </div>
              <FileUpload
                onFileLoaded={handleFileLoaded}
                isLoading={analyzeDocument.isPending}
              />
            </div>

            {/* Info Section */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-l-primary">
                <h3 className="font-bold text-foreground mb-2">Formatos Soportados</h3>
                <p className="text-sm text-muted-foreground">
                  PDF y archivos de texto plano (.txt)
                </p>
              </div>
              <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-l-primary">
                <h3 className="font-bold text-foreground mb-2">Análisis Automático</h3>
                <p className="text-sm text-muted-foreground">
                  Extrae y analiza secciones del documento
                </p>
              </div>
              <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-l-primary">
                <h3 className="font-bold text-foreground mb-2">100% Local</h3>
                <p className="text-sm text-muted-foreground">
                  Todo corre en tu navegador, sin APIs externas
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-foreground">Resultados del Análisis</h2>
              <button
                onClick={handleNewAnalysis}
                className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition"
              >
                Nuevo Análisis
              </button>
            </div>
            <SentimentResults
              sections={results.sections}
              overallSentiment={results.overallSentiment}
              fileName={results.fileName}
            />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-border mt-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 text-center text-sm text-muted-foreground">
          <p>© 2026 SEC Sentiment Analyzer. Análisis de sentimiento con IA local.</p>
        </div>
      </footer>
    </div>
  );
}
