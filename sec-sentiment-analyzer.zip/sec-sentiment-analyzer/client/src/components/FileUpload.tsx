import { useState, useRef } from 'react';
import { Upload, Loader2 } from 'lucide-react';
import * as pdfjs from 'pdfjs-dist';

// Configurar el worker de PDF.js
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

interface FileUploadProps {
  onFileLoaded: (content: string, fileName: string) => void;
  isLoading?: boolean;
}

export default function FileUpload({ onFileLoaded, isLoading = false }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const extractTextFromPDF = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjs.getDocument({ data: arrayBuffer }).promise;
    let fullText = '';

    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items
        .map((item: any) => item.str)
        .join(' ');
      fullText += pageText + '\n';
    }

    return fullText;
  };

  const extractTextFromTxt = async (file: File): Promise<string> => {
    return file.text();
  };

  const handleFile = async (file: File) => {
    if (!file) return;

    const fileName = file.name;
    const fileType = file.type;

    try {
      let content = '';

      if (fileType === 'application/pdf' || fileName.endsWith('.pdf')) {
        content = await extractTextFromPDF(file);
      } else if (fileType === 'text/plain' || fileName.endsWith('.txt')) {
        content = await extractTextFromTxt(file);
      } else {
        alert('Por favor, sube un archivo PDF o TXT');
        return;
      }

      onFileLoaded(content, fileName);
    } catch (error) {
      console.error('Error al procesar archivo:', error);
      alert('Error al procesar el archivo. Por favor, intenta de nuevo.');
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFile(files[0]);
    }
  };

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`border-2 border-dashed rounded-lg p-8 text-center transition ${
        isDragging
          ? 'border-primary bg-primary/10'
          : 'border-border bg-secondary/30 hover:border-primary'
      }`}
    >
      <input
        ref={fileInputRef}
        type="file"
        accept=".pdf,.txt"
        onChange={(e) => e.target.files && handleFile(e.target.files[0])}
        className="hidden"
      />

      <div className="flex flex-col items-center gap-4">
        {isLoading ? (
          <>
            <Loader2 className="w-12 h-12 text-primary animate-spin" />
            <p className="text-foreground font-medium">Procesando archivo...</p>
          </>
        ) : (
          <>
            <Upload className="w-12 h-12 text-primary" />
            <div>
              <p className="text-foreground font-medium mb-1">
                Arrastra un archivo aquí o haz clic para seleccionar
              </p>
              <p className="text-sm text-muted-foreground">
                Soporta PDF y TXT (máx. 50MB)
              </p>
            </div>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="mt-4 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition"
            >
              Seleccionar Archivo
            </button>
          </>
        )}
      </div>
    </div>
  );
}
