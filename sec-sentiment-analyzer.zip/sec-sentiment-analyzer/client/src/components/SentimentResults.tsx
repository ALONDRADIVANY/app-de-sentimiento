import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface SentimentResultsProps {
  sections: Array<{
    sectionName: string;
    content: string;
    sentiment: {
      sentiment: 'positive' | 'negative' | 'neutral';
      score: number;
      confidence: number;
      reasoning: string;
    };
  }>;
  overallSentiment: {
    sentiment: 'positive' | 'negative' | 'neutral';
    score: number;
    confidence: number;
  };
  fileName: string;
}

export default function SentimentResults({
  sections,
  overallSentiment,
  fileName,
}: SentimentResultsProps) {
  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'negative':
        return 'bg-red-100 text-red-800 border-red-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return <TrendingUp className="w-5 h-5" />;
      case 'negative':
        return <TrendingDown className="w-5 h-5" />;
      default:
        return <Minus className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-border rounded-lg p-6">
        <h2 className="text-2xl font-bold text-foreground mb-2">{fileName}</h2>
        <p className="text-muted-foreground">
          {sections.length} secciones analizadas
        </p>
      </div>

      {/* Overall Sentiment */}
      <div className={`border-2 rounded-lg p-6 ${getSentimentColor(overallSentiment.sentiment)}`}>
        <div className="flex items-center gap-3 mb-4">
          {getSentimentIcon(overallSentiment.sentiment)}
          <h3 className="text-xl font-bold">Sentimiento General</h3>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm opacity-75">Sentimiento</p>
            <p className="text-lg font-semibold capitalize">
              {overallSentiment.sentiment}
            </p>
          </div>
          <div>
            <p className="text-sm opacity-75">Puntuación</p>
            <p className="text-lg font-semibold">
              {(overallSentiment.score * 100).toFixed(1)}%
            </p>
          </div>
          <div>
            <p className="text-sm opacity-75">Confianza</p>
            <p className="text-lg font-semibold">
              {(overallSentiment.confidence * 100).toFixed(1)}%
            </p>
          </div>
        </div>
      </div>

      {/* Sections */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-foreground">Análisis por Sección</h3>
        {sections.map((section, idx) => (
          <div
            key={idx}
            className={`border-2 rounded-lg p-6 ${getSentimentColor(
              section.sentiment.sentiment
            )}`}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                {getSentimentIcon(section.sentiment.sentiment)}
                <div>
                  <h4 className="font-bold">{section.sectionName}</h4>
                  <p className="text-sm opacity-75 capitalize">
                    {section.sentiment.sentiment}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm opacity-75">Puntuación</p>
                <p className="text-lg font-bold">
                  {(section.sentiment.score * 100).toFixed(1)}%
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <p className="text-sm opacity-75 mb-1">Razonamiento</p>
                <p className="text-sm">{section.sentiment.reasoning}</p>
              </div>

              <div>
                <p className="text-sm opacity-75 mb-1">Contenido (primeras 300 caracteres)</p>
                <p className="text-sm line-clamp-3">
                  {section.content.substring(0, 300)}...
                </p>
              </div>

              <div className="flex gap-4 text-sm">
                <div>
                  <span className="opacity-75">Confianza: </span>
                  <span className="font-semibold">
                    {(section.sentiment.confidence * 100).toFixed(1)}%
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
