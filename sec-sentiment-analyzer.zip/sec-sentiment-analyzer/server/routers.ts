import { z } from 'zod';
import { router, publicProcedure } from './trpc';
import { analyzeSentiment, extractSections } from './sentimentAnalyzer';

export const appRouter = router({
  // Analizar sentimiento de un texto
  analyzeSentiment: publicProcedure
    .input(z.object({
      text: z.string().min(1, 'El texto no puede estar vacío'),
    }))
    .mutation(async ({ input }) => {
      const sentiment = await analyzeSentiment(input.text);
      return {
        success: true,
        sentiment,
      };
    }),

  // Extraer y analizar secciones de un documento
  analyzeSections: publicProcedure
    .input(z.object({
      text: z.string().min(1, 'El texto no puede estar vacío'),
    }))
    .mutation(async ({ input }) => {
      const sections = extractSections(input.text);
      return {
        success: true,
        sections,
        overallSentiment: calculateOverallSentiment(sections),
      };
    }),

  // Analizar un archivo completo
  analyzeDocument: publicProcedure
    .input(z.object({
      content: z.string().min(1, 'El contenido no puede estar vacío'),
      fileName: z.string(),
    }))
    .mutation(async ({ input }) => {
      const sections = extractSections(input.content);
      const overallSentiment = calculateOverallSentiment(sections);
      
      return {
        success: true,
        fileName: input.fileName,
        sections,
        overallSentiment,
        wordCount: input.content.split(/\s+/).length,
        charCount: input.content.length,
      };
    }),
});

/**
 * Calcula el sentimiento general basado en las secciones
 */
function calculateOverallSentiment(sections: any[]) {
  if (sections.length === 0) {
    return { sentiment: 'neutral', score: 0.5, confidence: 0 };
  }

  const avgScore = sections.reduce((sum, s) => sum + s.sentiment.score, 0) / sections.length;
  const avgConfidence = sections.reduce((sum, s) => sum + s.sentiment.confidence, 0) / sections.length;
  
  let sentiment: 'positive' | 'negative' | 'neutral' = 'neutral';
  if (avgScore > 0.6) sentiment = 'positive';
  else if (avgScore < 0.4) sentiment = 'negative';

  return {
    sentiment,
    score: avgScore,
    confidence: avgConfidence,
  };
}

export type AppRouter = typeof appRouter;
