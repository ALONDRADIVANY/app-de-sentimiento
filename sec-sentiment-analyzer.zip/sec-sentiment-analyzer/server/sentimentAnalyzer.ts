/**
 * Servicio de análisis de sentimiento usando Qwen2-0.5B Instruct
 * Este archivo contiene la lógica para analizar el sentimiento de textos SEC
 */

interface SentimentResult {
  sentiment: 'positive' | 'negative' | 'neutral';
  score: number;
  confidence: number;
  reasoning: string;
}

interface SectionAnalysis {
  sectionName: string;
  content: string;
  sentiment: SentimentResult;
}

/**
 * Analiza el sentimiento de un texto usando un prompt estructurado
 * En producción, esto usaría el modelo Qwen2-0.5B Instruct
 */
export async function analyzeSentiment(text: string): Promise<SentimentResult> {
  // Simulación de análisis de sentimiento
  // En producción, esto llamaría a invokeLLM con Qwen2-0.5B Instruct
  
  const prompt = `Analiza el sentimiento del siguiente texto de un documento SEC. 
Responde en JSON con los campos: sentiment (positive/negative/neutral), score (0-1), confidence (0-1), reasoning.

Texto: "${text.substring(0, 500)}"

Responde solo con JSON válido.`;

  try {
    // Simulación: análisis básico de palabras clave
    const positiveKeywords = ['growth', 'profit', 'increase', 'success', 'strong', 'improved', 'crecimiento', 'ganancia', 'aumento', 'éxito', 'fuerte', 'mejorado'];
    const negativeKeywords = ['loss', 'decline', 'risk', 'challenge', 'decrease', 'weak', 'pérdida', 'declive', 'riesgo', 'desafío', 'disminución', 'débil'];
    
    const lowerText = text.toLowerCase();
    const positiveCount = positiveKeywords.filter(word => lowerText.includes(word)).length;
    const negativeCount = negativeKeywords.filter(word => lowerText.includes(word)).length;
    
    let sentiment: 'positive' | 'negative' | 'neutral' = 'neutral';
    let score = 0.5;
    
    if (positiveCount > negativeCount) {
      sentiment = 'positive';
      score = Math.min(0.5 + (positiveCount * 0.1), 1);
    } else if (negativeCount > positiveCount) {
      sentiment = 'negative';
      score = Math.max(0.5 - (negativeCount * 0.1), 0);
    }
    
    return {
      sentiment,
      score,
      confidence: Math.min(0.7 + (Math.abs(positiveCount - negativeCount) * 0.05), 0.95),
      reasoning: `Análisis basado en palabras clave: ${positiveCount} positivas, ${negativeCount} negativas`,
    };
  } catch (error) {
    console.error('Error en análisis de sentimiento:', error);
    return {
      sentiment: 'neutral',
      score: 0.5,
      confidence: 0.3,
      reasoning: 'Error en el análisis',
    };
  }
}

/**
 * Divide el texto en secciones comunes de documentos SEC
 */
export function extractSections(text: string): SectionAnalysis[] {
  const commonSections = [
    { name: 'Business Overview', patterns: ['business overview', 'our business', 'descripción del negocio'] },
    { name: 'Risk Factors', patterns: ['risk factors', 'riesgos', 'factores de riesgo'] },
    { name: 'Financial Performance', patterns: ['financial performance', 'results of operations', 'desempeño financiero'] },
    { name: 'Management Discussion', patterns: ['management discussion', 'md&a', 'discusión y análisis'] },
    { name: 'Legal Proceedings', patterns: ['legal proceedings', 'procedimientos legales', 'litigios'] },
  ];

  const sections: SectionAnalysis[] = [];
  const lines = text.split('\n');
  let currentSection = 'General';
  let currentContent = '';

  for (const line of lines) {
    const lowerLine = line.toLowerCase();
    let foundSection = false;

    for (const section of commonSections) {
      if (section.patterns.some(pattern => lowerLine.includes(pattern))) {
        if (currentContent.trim()) {
          sections.push({
            sectionName: currentSection,
            content: currentContent.trim(),
            sentiment: analyzeSentimentSync(currentContent),
          });
        }
        currentSection = section.name;
        currentContent = '';
        foundSection = true;
        break;
      }
    }

    if (!foundSection) {
      currentContent += line + '\n';
    }
  }

  if (currentContent.trim()) {
    sections.push({
      sectionName: currentSection,
      content: currentContent.trim(),
      sentiment: analyzeSentimentSync(currentContent),
    });
  }

  return sections;
}

/**
 * Versión síncrona del análisis de sentimiento para uso interno
 */
function analyzeSentimentSync(text: string): SentimentResult {
  const positiveKeywords = ['growth', 'profit', 'increase', 'success', 'strong', 'improved', 'crecimiento', 'ganancia', 'aumento', 'éxito', 'fuerte', 'mejorado'];
  const negativeKeywords = ['loss', 'decline', 'risk', 'challenge', 'decrease', 'weak', 'pérdida', 'declive', 'riesgo', 'desafío', 'disminución', 'débil'];
  
  const lowerText = text.toLowerCase();
  const positiveCount = positiveKeywords.filter(word => lowerText.includes(word)).length;
  const negativeCount = negativeKeywords.filter(word => lowerText.includes(word)).length;
  
  let sentiment: 'positive' | 'negative' | 'neutral' = 'neutral';
  let score = 0.5;
  
  if (positiveCount > negativeCount) {
    sentiment = 'positive';
    score = Math.min(0.5 + (positiveCount * 0.1), 1);
  } else if (negativeCount > positiveCount) {
    sentiment = 'negative';
    score = Math.max(0.5 - (negativeCount * 0.1), 0);
  }
  
  return {
    sentiment,
    score,
    confidence: Math.min(0.7 + (Math.abs(positiveCount - negativeCount) * 0.05), 0.95),
    reasoning: `Análisis basado en palabras clave`,
  };
}
