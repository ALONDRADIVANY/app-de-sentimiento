# Guía de Inicio Rápido

## 5 Minutos para Empezar

### Paso 1: Clonar y Configurar

```bash
git clone https://github.com/tu-usuario/sec-sentiment-analyzer.git
cd sec-sentiment-analyzer
npm install
```

### Paso 2: Iniciar la Aplicación

```bash
npm run dev
```

Abre tu navegador en `http://localhost:5173`

### Paso 3: Cargar un Documento

1. Haz clic en "Seleccionar Archivo" o arrastra un archivo PDF/TXT
2. La aplicación analizará automáticamente el documento
3. Verás los resultados con sentimiento general y por sección

## Archivos de Ejemplo

Hemos incluido un archivo de ejemplo en `examples/sample-sec-filing.txt`. Puedes usarlo para probar la aplicación:

```bash
# Copiar el archivo de ejemplo
cp examples/sample-sec-filing.txt ~/Downloads/
```

Luego cárgalo en la aplicación.

## Estructura de Resultados

Cada análisis muestra:

- **Sentimiento General:** Clasificación agregada del documento
- **Puntuación:** Valor entre 0 (muy negativo) y 100 (muy positivo)
- **Confianza:** Qué tan seguro está el análisis
- **Secciones:** Análisis detallado de cada sección detectada

## Palabras Clave Detectadas

### Positivas
- growth, profit, increase, success, strong, improved, expansion, revenue, earnings

### Negativas
- loss, decline, risk, challenge, decrease, weak, disruption, uncertainty, adverse

## Solución de Problemas

### El servidor no inicia
```bash
# Verificar que el puerto 3001 esté disponible
lsof -i :3001

# O cambiar el puerto
PORT=3002 npm run dev
```

### Los archivos PDF no se cargan
- Asegúrate de que el archivo no esté corrompido
- Intenta con un archivo TXT primero
- Verifica que el archivo sea menor a 50MB

### Errores de compilación
```bash
# Limpiar caché y reinstalar
rm -rf node_modules package-lock.json
npm install
npm run dev
```

## Próximos Pasos

- Revisa el README.md para documentación completa
- Explora el código en `client/src/` y `server/`
- Contribuye con mejoras en GitHub

## Soporte

¿Preguntas? Abre un issue en el repositorio.
